import { FooterStyled } from "../../styles/FooterStyled";

export const Footer = () => {
  return <FooterStyled>Copyright Andrius Z</FooterStyled>;
};
